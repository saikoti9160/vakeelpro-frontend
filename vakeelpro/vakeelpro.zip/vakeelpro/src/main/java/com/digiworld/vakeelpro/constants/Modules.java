package com.digiworld.vakeelpro.constants;

public enum Modules {
	UserManagement, Dashboard, RoleManagement, CaseManagement, MasterDataManagement,UserProfile, CompanyProfile,
	InoviceManagement
}
