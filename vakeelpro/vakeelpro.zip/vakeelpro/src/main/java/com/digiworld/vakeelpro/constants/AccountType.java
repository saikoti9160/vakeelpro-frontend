package com.digiworld.vakeelpro.constants;

public enum AccountType {
    SUPER_ADMIN,
    ORGANIZATION,
    INDIVIDUAL
}